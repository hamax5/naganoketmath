#!/bin/sh
cd "/Users/hama/Dropbox/Hama/Oyama2018/fig/rpcutline2"
/Library/Frameworks/R.framework/Versions/Current/Resources/bin/R  --vanilla --slave < rppara1.r 2> errormessageR.txt
exit 0
