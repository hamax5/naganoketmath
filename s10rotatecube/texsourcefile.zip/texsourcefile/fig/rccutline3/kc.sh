#!/bin/sh
cd "/Users/hama/Dropbox/Hama/Oyama2018/fig/rccutline3"
/Library/Frameworks/R.framework/Versions/Current/Resources/bin/R  --vanilla --slave < rcpara3.r 2> errormessageR.txt
exit 0
