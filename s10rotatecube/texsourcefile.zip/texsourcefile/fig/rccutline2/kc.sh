#!/bin/sh
cd "/Users/hama/Dropbox/Hama/Oyama2018/fig/rccutline2"
/Library/Frameworks/R.framework/Versions/Current/Resources/bin/R  --vanilla --slave < rcpara2.r 2> errormessageR.txt
exit 0
